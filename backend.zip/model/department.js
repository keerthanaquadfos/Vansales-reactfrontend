module.exports = (sequelize, Sequelize) => {
    const Category = sequelize.define("department", { 
      name: {
        type: Sequelize.STRING
      }  
    }); 
    return Category;
  };