module.exports = (sequelize, Sequelize) => {
    const Category = sequelize.define("designation", { 
      name: {
        type: Sequelize.STRING
      }  
    }); 
    return Category;
  };